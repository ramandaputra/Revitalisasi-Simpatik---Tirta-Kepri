<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <title>Lokasi Sensor</title>
    <style type="text/css">
        #mapid {
            margin: 0 auto 0 auto;
            height: 100vh;
            /* Set tinggi ke 100% dari tinggi viewport */
            width: 100%;
        }

        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
    </style>
</head>

<body>

    <div id="mapid"></div>
    <div id="street-view"></div>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB861q02tPb43SuX8bSUB_mGJgo1KJ-YjE&callback=initMap&loading=async"></script>
    <script type="text/javascript">
        var map, streetView;

        function initMap() {
            var mapOptions = {
                center: {
                    lat: 0.9459632,
                    lng: 104.5376734
                },
                zoom: 12,
                mapTypeId: 'satellite'
            };

            var map = new google.maps.Map(document.getElementById('mapid'), mapOptions);
            streetView = new google.maps.StreetViewPanorama(document.getElementById('street-view'));
            map.setStreetView(streetView);

            $.getJSON("get_geojson.php", function(geojsonData) {
                var geojsonLayer = new google.maps.Data({
                    map: map
                });

                geojsonLayer.setStyle({
                    strokeColor: 'orange', // Atur warna garis menjadi hijau
                    strokeWeight: 2, // Atur lebar garis
                    strokeOpacity: 0.8 // Atur opasitas garis
                });

                geojsonLayer.addGeoJson(geojsonData);
            });


            $.getJSON("get_markers.php", function(markerData) {
                markerData.forEach(marker => {
                    var popupContent = `<b>${marker.name}</b><br>
                            <u>${marker.time}</u><br>
                            Pressure: ${marker.pressure} bar<br>
                            Flow: ${marker.flow} m³/h<br>
                            TDS: ${marker.tds} ppm<br>
                            Level: ${marker.level} m`;

                    var infowindow = new google.maps.InfoWindow({
                        content: popupContent,
                    });

                    // Hitung ukuran lingkaran berdasarkan nilai pressure
                    var circleRadius = calculateCircleRadius(marker.pressure);

                    var circleColor = marker.pressure >= 1 ? 'blue' : 'red'; // Warna biru untuk pressure >= 1, merah untuk pressure < 1

                    // Tambahkan marker dengan lingkaran (circle) dan label
                    var markerWithLabel = new google.maps.Marker({
                        position: new google.maps.LatLng(parseFloat(marker.latitude), parseFloat(marker.longitude)),
                        map: map,
                        label: {
                            text: marker.name,
                            fontSize: '12px',
                        },
                        icon: {
                            path: google.maps.SymbolPath.CIRCLE,
                            scale: circleRadius,
                            fillColor: circleColor, // Warna lingkaran
                            fillOpacity: 0.6, // Opasitas warna lingkaran
                            strokeWeight: 0, // Tidak ada border
                        },
                    });

                    // Tambahkan listener untuk menampilkan infowindow saat marker diklik
                    markerWithLabel.addListener('click', function() {
                        infowindow.open(map, markerWithLabel);
                    });

                    map.setCenter(new google.maps.LatLng(parseFloat(marker.latitude), parseFloat(marker.longitude)));
                });
            });

            // Fungsi untuk menghitung ukuran lingkaran berdasarkan nilai pressure
            function calculateCircleRadius(pressure) {
                return Math.max(0, 12 - pressure); // Contoh sederhana
            }

        }
    </script>
</body>

</html>