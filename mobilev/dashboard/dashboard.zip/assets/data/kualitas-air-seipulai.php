<?php
include 'koneksi.php';
$sql = "SELECT id, DATE_FORMAT(waktu, '%d/%m/%Y %H:%i:%s') as waktu, tds, ph, waduk FROM kualitas_air ORDER BY waktu DESC LIMIT 7";
$result = $connk->query($sql);

$tasks = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
}

$connk->close();

header('Content-Type: application/json');
echo json_encode($tasks);
