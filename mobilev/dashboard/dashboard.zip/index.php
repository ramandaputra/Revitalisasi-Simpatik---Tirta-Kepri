<?php
session_start();
$is_logged_in = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<!--
Item Name: Elisyam - Web App & Admin Dashboard Template
Version: 1.5
Author: SAEROX

** A license must be purchased in order to legally use this template for your project **
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SIMPATIK V2.0 - Dashboard</title>
    <meta name="description" content="SIMPATIK">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Google Fonts -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB861q02tPb43SuX8bSUB_mGJgo1KJ-YjE&callback=initMap"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
    <script>
        WebFont.load({
            google: {
                "families": ["Montserrat:400,500,600,700", "Noto+Sans:400,700"]
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5-dark.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel/owl.theme.min.css">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>

<body id="page-top">
    <!-- Begin Preloader -->
    <div id="preloader">
        <div class="canvas">
            <img src="assets/img/logo-2.png" alt="logo" class="loader-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- End Preloader -->
    <div class="page">
        <!-- Begin Header -->
        <header class="header">
            <nav class="navbar fixed-top">
                <!-- Begin Search Box-->
                <div class="search-box">
                    <button class="dismiss"><i class="ion-close-round"></i></button>
                    <form id="searchForm" action="#" role="search">
                        <input type="search" placeholder="Search something ..." class="form-control">
                    </form>
                </div>
                <!-- End Search Box-->
                <!-- Begin Topbar -->
                <div class="navbar-holder d-flex align-items-center align-middle justify-content-between">
                    <!-- Begin Logo -->
                    <div class="navbar-header">
                        <a href="db-default.html" class="navbar-brand">
                            <div class="brand-image brand-big">
                                <img src="assets/img/logo-big-2.png" alt="logo" class="logo-big">
                            </div>
                            <div class="brand-image brand-small">
                                <img src="assets/img/logo-2.png" alt="logo" class="logo-small">
                            </div>
                        </a>
                        <!-- Toggle Button -->
                        <a id="toggle-btn" href="#" class="menu-btn active">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                        <!-- End Toggle -->
                    </div>
                    <!-- End Logo -->
                    <!-- Begin Navbar Menu -->
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center pull-right">
                        <!-- User -->
                        <li class="nav-item dropdown">
                            <?php if ($is_logged_in) : ?>
                                <a id="user" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link">
                                    <img src="assets/img/avatar/avatar-01.jpg" alt="..." class="avatar rounded-circle">
                                </a>
                                <ul aria-labelledby="user" class="user-size dropdown-menu">
                                    <li class="welcome">
                                        <a href="#" class="edit-profil"><i class="la la-gear"></i></a>
                                        <img src="assets/img/avatar/avatar-01.jpg" alt="..." class="rounded-circle">
                                    </li>
                                    <li>
                                        <a href="pages-profile.html" class="dropdown-item">Profile</a>
                                    </li>
                                    <li>
                                        <a href="#" class="dropdown-item no-padding-bottom">Settings</a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" href="pages-logout.php" class="dropdown-item logout text-center"><i class="ti-power-off"></i></a>
                                    </li>
                                </ul>
                            <?php else : ?>
                                <button type="button" class="btn btn-shadow mr-1 mb-2" onclick="window.location.href='pages-login.html'">Login</button>
                            <?php endif; ?>
                        </li>
                        <!-- End User -->
                    </ul>
                    <!-- End Navbar Menu -->
                </div>
                <!-- End Topbar -->
            </nav>
        </header>
        <!-- End Header -->
        <!-- Begin Page Content -->
        <div class="page-content d-flex align-items-stretch">
            <div class="default-sidebar">
                <!-- Begin Side Navbar -->
                <nav class="side-navbar box-scroll sidebar-scroll">
                    <!-- Begin Main Navigation -->
                    <ul class="list-unstyled">
                        <span class="heading">Kinerja</span>
                        <li><a href="#keuangan" aria-expanded="false" data-toggle="collapse"><i class="la la-money"></i><span>Aspek Keuangan</span></a>
                            <ul id="keuangan" class="collapse list-unstyled pt-0">
                                <li><a href="return-on-equity.php">Return on Equity</a></li>
                                <li><a href="ratio-operasi.php">Rasio Operasi</a></li>
                                <li><a href="cash-ratio.php">Rasio Kas</a></li>
                                <li><a href="efisiensi-penagihan.php">Efisiensi Penagihan</a></li>
                                <li><a href="solvabilitas.php">Solvabilitas</a></li>
                            </ul>
                        </li>
                        <li><a href="#pelayanan" aria-expanded="false" data-toggle="collapse"><i class="la la-thumbs-up"></i><span>Aspek Pelayanan</span></a>
                            <ul id="pelayanan" class="collapse list-unstyled pt-0">
                                <li><a href="cakupan-pelayanan.php">Cakupan Pelayanan</a></li>
                                <li><a href="pertumbuhan-pelanggan.php">Pertumbuhan Pelanggan</a></li>
                                <li><a href="penyelesaian-pengaduan.php">Penyelesaian Pengaduan</a></li>
                                <li><a href="kualitas-air.php">Kualitas Air</a></li>
                                <li><a href="konsumsi-air.php">Konsumsi Air</a></li>
                            </ul>
                        </li>
                        <li><a href="#operasional" aria-expanded="false" data-toggle="collapse"><i class="la la-tint"></i><span>Aspek Operasional</span></a>
                            <ul id="operasional" class="collapse list-unstyled pt-0">
                                <li><a href="rasio-efisiensi-produksi.php">Rasio Efisiensi Produksi</a></li>
                                <li><a href="air-tidak-berekening.php">Air Tidak Berekening</a></li>
                                <li><a href="jam-operasi.php">Jam Operasi</a></li>
                                <li><a href="tekanan-air.php">Tekanan Air</a></li>
                                <li><a href="penggantian-meter.php">Penggantian Meter</a></li>
                            </ul>
                        </li>
                        <li><a href="#sdm" aria-expanded="false" data-toggle="collapse"><i class="la la-group"></i><span>Aspek SDM</span></a>
                            <ul id="sdm" class="collapse list-unstyled pt-0">
                                <li><a href="jumlah-pegawai.php">Jumlah Pegawai</a></li>
                                <li><a href="rasio-pegawai-diklat.php">Rasio Pegawai Diklat</a></li>
                                <li><a href="rasio-biaya-diklat.php">Rasio Biaya Diklat</a></li>
                            </ul>
                        </li>
                    </ul>
                    <span class="heading">Target x Realisasi</span>
                    <ul class="list-unstyled">
                        <li><a href="#tek" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>TEKNIK</span></a>
                            <ul id="tek" class="collapse list-unstyled pt-0">
                                <li><a href="produksi.php">Produksi</a></li>
                                <li><a href="distribusi.php">Distribusi</a></li>
                                <li><a href="tingkat-kehilangan-air.php">Tingkat Kehilangan Air</a></li>
                                <li><a href="perawatan-meter.php">Perawatan Meter</a></li>
                                <li><a href="pemutusan-tunggakan.php">Pemutusan Tunggakan</a></li>
                            </ul>
                        </li>
                        <li><a href="#hbl" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>HUBLANG</span></a>
                            <ul id="hbl" class="collapse list-unstyled pt-0">
                                <li><a href="drd-posting.php">DRD Posting</a></li>
                                <li><a href="pertumbuhan-pelanggan.php">Pertumbuhan Pelanggan</a></li>
                                <li><a href="pengaduan-pelanggan.php">Pengaduan Pelanggan</a></li>
                                <li><a href="perbaikan-rekening.php">Perbaikan Rekening</a></li>
                                <li><a href="pembacaan-meter.php">Pembacaan Meter</a></li>
                            </ul>
                        </li>
                        <li><a href="#keu" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>KEUANGAN</span></a>
                            <ul id="keu" class="collapse list-unstyled pt-0">
                                <li><a href="efisiensi-penagihan.php">Efisiensi Penagihan</a></li>
                                <li><a href="penerimaan.php">Penerimaan</a></li>
                                <li><a href="pengeluaran.php">Pengeluaran</a></li>
                                <li><a href="arus-kas.php">Arus Kas</a></li>
                            </ul>
                        </li>
                        <li><a href="#spi" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>SPI</span></a>
                            <ul id="spi" class="collapse list-unstyled pt-0">
                                <li><a href="tunggakan-empat-bulan.php">Tunggakan > 4 Bulan</a></li>
                                <li><a href="monitoring-spi.php">Monitoring SPI</a></li>
                            </ul>
                        </li>
                        <li><a href="#spka" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>SPKA</span></a>
                            <ul id="spka" class="collapse list-unstyled pt-0">
                                <li><a href="monitoring-dma.php">Monitoring DMA</a></li>
                                <li><a href="kegiatan-spka.php">Kegiatan SPKA</a></li>
                                <li><a href="gis.php">GIS</a></li>
                            </ul>
                        </li>
                        <li><a href="maps-leaflet.html"><i class="la la-map"></i><span>Maps</span></a></li>
                    </ul>
                    <span class="heading">Input Data</span>
                    <ul class="list-unstyled">
                        <?php if ($is_logged_in) : ?>
                            <li><a href="#aspek-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>Posting Kinerja</span></a>
                                <ul id="aspek-input" class="collapse list-unstyled pt-0">
                                    <li><a href="aspek-keuangan-input.php">Aspek Keuangan</a></li>
                                    <li><a href="aspek-pelayanan-input.php">Aspek Pelayanan</a></li>
                                    <li><a href="aspek-operasional-input.php">Aspek Operasional</a></li>
                                    <li><a href="aspek-sdm-input.php">Aspek SDM</a></li>
                                </ul>
                            </li>
                            <li><a href="#produksi-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>Jurnal Produksi</span></a>
                                <ul id="produksi-input" class="collapse list-unstyled pt-0">
                                    <li><a href="air-baku-input.php">Air Baku</a></li>
                                    <li><a href="ipa-input.php">IPA</a></li>
                                    <li><a href="pompa-input.php">Pompa</a></li>
                                </ul>
                            </li>
                            <li><a href="#spka-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>SPKA</span></a>
                                <ul id="spka-input" class="collapse list-unstyled pt-0">
                                    <li><a href="monitoring-dma-input.php">Monitoring DMA</a></li>
                                    <li><a href="kegiatan-spka-input.php">Kegiatan SPKA</a></li>
                                </ul>
                            </li>
                            <li><a href="#spi-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>SPI</span></a>
                                <ul id="spi-input" class="collapse list-unstyled pt-0">
                                    <li><a href="monitoring-dma-input.php">Monitoring SPI</a></li>
                                </ul>
                            </li>
                            <li><a href="#user-input" aria-expanded="false" data-toggle="collapse"><i class="la la-key"></i><span>Users</span></a>
                                <ul id="user-input" class="collapse list-unstyled pt-0">
                                    <li><a href="registrasi.php">Registrasi</a></li>
                                    <li><a href="reset-password.php">Reset Password</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <!-- End Main Navigation -->
                </nav>
                <!-- End Side Navbar -->
            </div>
            <!-- End Left Sidebar -->
            <div class="content-inner">
                <div class="container-fluid">
                    <!-- Begin Page Header-->
                    <div class="row">
                        <div class="page-header">
                            <div class="d-flex align-items-center">
                                <h2 class="page-header-title">Dashboard</h2>
                                <div>
                                    <div class="page-header-tools">
                                        <a class="btn btn-gradient-01" href="index.php">Dashboard</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Page Header -->
                    <!-- Begin Row -->
                    <div class="row flex-row">
                        <!-- Begin Facebook -->
                        <div class="col-xl-4 col-md-6 col-sm-6">
                            <div class="widget widget-12 has-shadow">
                                <div class="widget-body">
                                    <div class="media">
                                        <div class="align-self-center ml-5 mr-5">
                                            <i class="ion-person-stalker text-twitter"></i>
                                        </div>
                                        <div class="pelanggan-stats align-self-center">
                                            <div class="title text-twitter">Pelanggan Aktif</div>
                                            <div class="number">Loading...</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Facebook -->
                        <!-- Begin Twitter -->
                        <div class="col-xl-4 col-md-6 col-sm-6">
                            <div class="widget widget-12 has-shadow">
                                <div class="widget-body">
                                    <div class="media">
                                        <div class="align-self-center ml-5 mr-5">
                                            <i class="ion-waterdrop text-twitter"></i>
                                        </div>
                                        <div class="pelanggan-stats align-self-center">
                                            <div class="title text-twitter">Penjualan</div>
                                            <div class="number">Loading...</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Twitter -->
                        <!-- Begin Linkedin -->
                        <div class="col-xl-4 col-md-6 col-sm-6">
                            <div class="widget widget-12 has-shadow">
                                <div class="widget-body">
                                    <div class="media">
                                        <div class="align-self-center ml-5 mr-5">
                                            <i class="ion-cash text-twitter"></i>
                                        </div>
                                        <div class="pelanggan-stats align-self-center">
                                            <div class="title text-twitter">Penagihan</div>
                                            <div class="number">Laoding...</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Linkedin -->
                    </div>
                    <!-- End Row -->
                    <!-- Begin Row -->
                    <div class="row flex-row">
                        <div class="col-xl-12 col-md-6">
                            <!-- Begin Widget 09 -->
                            <div class="widget widget-09 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header d-flex align-items-center">
                                    <h2>Produktifitas Petugas Bacameter</h2>
                                    <div class="widget-options">
                                        <button type="button" class="btn btn-shadow">View all</button>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="widget-body">
                                    <div class="row">
                                        <div class="col-xl-10 col-12 no-padding">
                                            <div>
                                                <canvas id="orders"></canvas>
                                            </div>
                                        </div>
                                        <div class="col-xl-2 col-12 d-flex flex-column my-auto no-padding text-center">
                                            <div class="new-orders">
                                                <div class="title">Progress Baca</div>
                                                <div class="circle-orders">
                                                    <div class="percent-orders"></div>
                                                </div>
                                            </div>
                                            <div class="some-stats mt-5">
                                                <div class="title">Total Baca</div>
                                                <div class="number text-blue">0</div>
                                            </div>
                                            <div class="some-stats mt-3">
                                                <div class="title">Total Problem</div>
                                                <div class="number text-blue">0</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Widget 09 -->
                        </div>
                    </div>
                    <!-- End Row -->
                    <div class="row flex-row">
                        <div class="col-xl-8 col-md-6">
                            <!-- Begin Widget 04 -->
                            <div class="widget widget-04 has-shadow">
                                <!-- Begin Widget Header -->
                                <!-- Leaflet -->
                                <div class="widget widget-38 has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>GIS</h4>
                                    </div>
                                    <div class="widget-body p-0">
                                        <div id="layer-control" style="height: 485px"></div>
                                    </div>
                                    <!-- End Leaflet -->
                                </div>
                                <!-- End Widget Header -->
                            </div>
                            <!-- End Widget 04 -->
                        </div>
                        <div class="col-xl-4">
                            <!-- Begin Widget 06 -->
                            <div class="widget widget-06 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Pengaduan Pelanggan</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Edit Widget
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="widget-body p-0">
                                    <div id="list-group" class="widget-scroll" style="max-height:490px;">
                                        <ul class="reviews list-group w-100">
                                            <!-- 01 -->
                                            <li class="list-group-item">
                                                <div class="media">
                                                    <div class="media-left align-self-start">
                                                        <img src="assets/img/avatar/avatar-02.jpg" class="user-img rounded-circle" alt="...">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="username">
                                                            <h4>Brandon Smith</h4>
                                                        </div>
                                                        <div class="msg">
                                                            <div class="stars">
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star-half-empty"></i>
                                                            </div>
                                                            <p>
                                                                WoW! Amazing Work!
                                                            </p>
                                                        </div>
                                                        <div class="meta">
                                                            <span class="mr-3">30 minutes ago - 1 Reply</span>
                                                            <a href="#">Reply</a>
                                                        </div>
                                                    </div>
                                                    <div class="media-right pr-3 align-self-center">
                                                        <div class="like text-center">
                                                            <i class="ion-heart"></i>
                                                            <span>12</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End 01 -->
                                            <!-- 02 -->
                                            <li class="list-group-item">
                                                <div class="media">
                                                    <div class="media-left align-self-start">
                                                        <img src="assets/img/avatar/avatar-05.jpg" class="user-img rounded-circle" alt="...">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="username">
                                                            <h4>Megan Duncan</h4>
                                                        </div>
                                                        <div class="msg">
                                                            <div class="stars">
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                            </div>
                                                            <p>
                                                                Very nice! Keep up the beautiful work.
                                                            </p>
                                                        </div>
                                                        <div class="meta">
                                                            <span class="mr-3">2 hours ago</span>
                                                            <a href="#">Reply</a>
                                                        </div>
                                                    </div>
                                                    <div class="media-right pr-3 align-self-center">
                                                        <div class="like text-center">
                                                            <i class="ion-heart"></i>
                                                            <span>4</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End 02 -->
                                            <!-- 03 -->
                                            <li class="list-group-item">
                                                <div class="media">
                                                    <div class="media-left align-self-start">
                                                        <img src="assets/img/avatar/avatar-04.jpg" class="user-img rounded-circle" alt="...">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="username">
                                                            <h4>Nathan Hunter</h4>
                                                        </div>
                                                        <div class="msg">
                                                            <div class="stars">
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                            </div>
                                                            <p>
                                                                Nice work, good design!
                                                            </p>
                                                        </div>
                                                        <div class="meta">
                                                            <span class="mr-3">4 hours ago</span>
                                                            <a href="#">Reply</a>
                                                        </div>
                                                    </div>
                                                    <div class="media-right pr-3 align-self-center">
                                                        <div class="like text-center">
                                                            <i class="ion-heart"></i>
                                                            <span>32</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End 03 -->
                                            <!-- 04 -->
                                            <li class="list-group-item">
                                                <div class="media">
                                                    <div class="media-left align-self-start">
                                                        <img src="assets/img/avatar/avatar-09.jpg" class="user-img rounded-circle" alt="...">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="username">
                                                            <h4>Michael Bradley</h4>
                                                        </div>
                                                        <div class="msg">
                                                            <div class="stars">
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star-half-empty"></i>
                                                            </div>
                                                            <p>
                                                                Very nice! Keep up the beautiful work.
                                                            </p>
                                                        </div>
                                                        <div class="meta">
                                                            <span class="mr-3">5 hours ago - 2 Reply</span>
                                                            <a href="#">Reply</a>
                                                        </div>
                                                    </div>
                                                    <div class="media-right pr-3 align-self-center">
                                                        <div class="like text-center">
                                                            <i class="ion-heart"></i>
                                                            <span>2</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End 04 -->
                                            <!-- 05 -->
                                            <li class="list-group-item">
                                                <div class="media">
                                                    <div class="media-left align-self-start">
                                                        <img src="assets/img/avatar/avatar-03.jpg" class="user-img rounded-circle" alt="...">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="username">
                                                            <h4>Louis Henry</h4>
                                                        </div>
                                                        <div class="msg">
                                                            <div class="stars">
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star"></i>
                                                                <i class="la la-star-half-empty"></i>
                                                            </div>
                                                            <p>
                                                                I like the color combination!
                                                            </p>
                                                        </div>
                                                        <div class="meta">
                                                            <span class="mr-3">1 day ago</span>
                                                            <a href="#">Reply</a>
                                                        </div>
                                                    </div>
                                                    <div class="media-right pr-3 align-self-center">
                                                        <div class="like text-center">
                                                            <i class="ion-heart"></i>
                                                            <span>9</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <!-- End 05 -->
                                        </ul>
                                    </div>
                                    <!-- End List -->
                                </div>
                                <!-- End Widget Body -->
                            </div>
                            <!-- End Widget 06 -->
                        </div>
                    </div>
                    <!-- End Row -->
                    <div class="row flex-row">
                        <div class="col-xl-12">
                            <!-- Begin Widget 07 -->
                            <div class="widget widget-07 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Monitoring DMA</h2>
                                    <div class="widget-options">
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-primary ripple">Week</button>
                                            <button type="button" class="btn btn-primary ripple">Month</button>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="container mt-5">
                                    <div class="table-responsive table-scroll" style="max-height:10020px;">
                                        <table class="table table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div class="styled-checkbox mt-2">
                                                            <input type="checkbox" name="check-all" id="check-all">
                                                            <label for="check-all"></label>
                                                        </div>
                                                    </th>
                                                    <th>DMA</th>
                                                    <th>Pelanggan (SL)</th>
                                                    <th>Distribusi (m³)</th>
                                                    <th>Pemakaian (m³)</th>
                                                    <th>Kehilangan (m³)</th>
                                                    <th>%</th>
                                                </tr>
                                            </thead>
                                            <tbody id="order-table-body">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- End Widget Body -->
                            </div>
                            <!-- End Widget 07 -->
                        </div>
                    </div>
                    <div class="row flex-row">
                        <div class="col-xl-3 col-md-6">
                            <!-- Begin Widget 08 -->
                            <div class="widget widget-08 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Tasks List</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-plus"></i>Add Task
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Edit Widget
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="widget-body">
                                    <div class="today">
                                        <div class="title">Today</div>
                                        <div class="new-tasks"><span class="nb">12</span> new tasks</div>
                                    </div>
                                    <!-- Begin List -->
                                    <div class="todo-list">
                                        <ul id="sortable" class="list">
                                            <li class="task-color task-orange">
                                                <div class="styled-checkbox">
                                                    <input type="checkbox" id="task-1">
                                                    <label class="text-secondary" for="task-1">Play Rainbow Six</label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="styled-checkbox">
                                                    <input type="checkbox" id="task-2">
                                                    <label class="text-white" for="task-2">Drink coffee with Megan</label>
                                                </div>
                                            </li>
                                            <li class="task-color task-blue">
                                                <div class="styled-checkbox">
                                                    <input type="checkbox" id="task-3">
                                                    <label class="text-info" for="task-3">Video conference</label>
                                                </div>
                                            </li>
                                            <li class="task-color task-red">
                                                <div class="styled-checkbox">
                                                    <input type="checkbox" id="task-4">
                                                    <label class="text-danger" for="task-4">Finish visual design</label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="styled-checkbox">
                                                    <input type="checkbox" id="task-5">
                                                    <label class="text-white" for="task-5">Meeting with team</label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- End List -->
                                </div>
                                <!-- End Widget Body -->
                            </div>
                            <!-- End Widget 08 -->
                        </div>
                        <div class="col-xl-5 col-md-6">
                            <!-- Begin Widget 10 -->
                            <div class="widget widget-10 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Support Tickets</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-bell-slash"></i>Disable Alerts
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Edit Widget
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="widget-body no-padding">
                                    <ul class="ticket list-group w-100">
                                        <!-- 01 -->
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center pr-4">
                                                    <img src="assets/img/avatar/avatar-02.jpg" class="user-img rounded-circle" alt="...">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="username">
                                                        <h4>Brandon Smith</h4>
                                                    </div>
                                                    <div class="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                                                        </p>
                                                    </div>
                                                    <div class="status"><span class="open mr-2">Open</span>(1 hour ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        <!-- End 01 -->
                                        <!-- 02 -->
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center pr-4">
                                                    <img src="assets/img/avatar/avatar-04.jpg" class="user-img rounded-circle" alt="...">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="username">
                                                        <h4>Nathan Hunter</h4>
                                                    </div>
                                                    <div class="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                                                        </p>
                                                    </div>
                                                    <div class="status"><span class="pending mr-2">Pending</span>(2 hours ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        <!-- End 02 -->
                                        <!-- 03 -->
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center pr-4">
                                                    <img src="assets/img/avatar/avatar-05.jpg" class="user-img rounded-circle" alt="...">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="username">
                                                        <h4>Megan Duncan</h4>
                                                    </div>
                                                    <div class="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                                                        </p>
                                                    </div>
                                                    <div class="status"><span class="closed mr-2">Closed</span>(1 day ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        <!-- End 03 -->
                                    </ul>
                                </div>
                                <!-- End Widget Body -->
                            </div>
                            <!-- End Widget 10 -->
                        </div>
                        <div class="col-xl-4">
                            <!-- Begin Widget 11 -->
                            <div class="widget widget-11 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Activity Log</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-history"></i>History
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-bell-slash"></i>Disable Alerts
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Edit Widget
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="widget-body p-0 widget-scroll" style="max-height:450px;">
                                    <!-- Begin 01 -->
                                    <div class="timeline violet">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="user-image">
                                                <img class="rounded-circle" src="assets/img/avatar/avatar-06.jpg" alt="...">
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    <span class="username">Beverly Oliver</span>
                                                    Send you a friend request
                                                </div>
                                                <div class="time">4 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 01 -->
                                    <!-- Begin 02 -->
                                    <div class="timeline red">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="timeline-icon">
                                                <i class="la la-spinner"></i>
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    Server rebooted
                                                </div>
                                                <div class="time">10 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 02 -->
                                    <!-- Begin 03 -->
                                    <div class="timeline violet">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="user-image">
                                                <img class="rounded-circle" src="assets/img/avatar/avatar-05.jpg" alt="...">
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    <span class="username">Megan Duncan</span>
                                                    Followed 4 people
                                                    <div class="users-like">
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-01.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-02.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-07.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-09.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="time">12 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 03 -->
                                    <!-- Begin 04 -->
                                    <div class="timeline blue">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="timeline-icon">
                                                <i class="la la-heart-o"></i>
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    <span class="username">Brandon Smith</span>
                                                    Liked <span class="font-weight-bold"><a href="#">Elisyam Admin Template</a></span>
                                                </div>
                                                <div class="time">30 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 04 -->
                                    <!-- Begin 05 -->
                                    <div class="timeline violet">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="timeline-icon">
                                                <i class="la la-twitter"></i>
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    + 3 new followers
                                                    <div class="users-like">
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-09.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-06.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                        <a href="profile.html">
                                                            <img src="assets/img/avatar/avatar-03.jpg" class="img-fluid rounded-circle" alt="...">
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="time">34 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 05 -->
                                    <!-- Begin 06 -->
                                    <div class="timeline violet">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="user-image">
                                                <img class="rounded-circle" src="assets/img/avatar/avatar-04.jpg" alt="...">
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    <span class="username">Nathan Hunter</span>
                                                    Invited you in a group
                                                </div>
                                                <div class="time">42 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 06 -->
                                    <!-- Begin 06 -->
                                    <div class="timeline violet">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="user-image">
                                                <img class="rounded-circle" src="assets/img/avatar/avatar-03.jpg" alt="...">
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    <span class="username">Louis Henry</span>
                                                    Is now following you
                                                </div>
                                                <div class="time">50 min ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 06 -->
                                    <!-- Begin 07 -->
                                    <div class="timeline blue">
                                        <div class="timeline-content d-flex align-items-center">
                                            <div class="timeline-icon">
                                                <i class="la la-image"></i>
                                            </div>
                                            <div class="d-flex flex-column mr-auto">
                                                <div class="title">
                                                    <span class="username">Brandon Smith</span>
                                                    Uploaded <span class="font-weight-bold"><a href="#">8 photos</a></span>
                                                </div>
                                                <div class="time">1 hour ago</div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End 07 -->
                                </div>
                                <!-- End Widget Body -->
                            </div>
                            <!-- End Widget 11 -->
                        </div>
                    </div>
                    <!-- End Row -->
                    <div class="row no-margin">
                        <div class="col-xl-12">
                            <!-- Begin Widget -->
                            <div class="row widget has-shadow">
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Calendar</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    Add Event
                                                </a>
                                                <a href="app-calendar.html" class="dropdown-item">
                                                    Basic Calendar
                                                </a>
                                                <a href="app-calendar-list.html" class="dropdown-item">
                                                    List Views
                                                </a>
                                                <a href="app-calendar-event.html" class="dropdown-item">
                                                    External Events
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <!-- Begin Widget Body -->
                                <div class="widget-body">
                                    <!-- Begin Calendar -->
                                    <div id="demo-calendar"></div>
                                    <!-- End Calendar -->
                                </div>
                                <!-- End Widget Body -->
                            </div>
                            <!-- End Widget -->
                        </div>
                        <!-- End Col -->
                    </div>
                    <!-- End Row -->
                    <!-- Begin Row -->
                    <div class="row flex-row">
                        <!-- Begin Widget 18 -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="widget widget-18 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Messages Box</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="app-chat.html" class="dropdown-item">
                                                    <i class="la la-comments"></i>New Message
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-bell-slash"></i>Disable Alerts
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Edit Widget
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <div class="widget-body">
                                    <div class="input-group">
                                        <span class="input-group-addon pr-0 pl-0">
                                            <a class="btn" href="#">
                                                <i class="la la-search la-2x"></i>
                                            </a>
                                        </span>
                                        <input type="text" class="form-control no-ppading-right no-padding-left" placeholder="Search">
                                    </div>
                                    <div class="new-message">
                                        <div class="media">
                                            <div class="media-left align-self-center mr-3">
                                                <img src="assets/img/avatar/avatar-04.jpg" alt="..." class="img-fluid rounded-circle" style="width: 50px;">
                                            </div>
                                            <div class="media-body align-self-center">
                                                <div class="new-message-sender">Nathan Hunter</div>
                                                <div class="new-message-time">New message about 2 minutes ago</div>
                                            </div>
                                            <div class="media-right align-self-center">
                                                <div class="actions">
                                                    <a href="app-chat.html"><i class="la la-reply reply"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="list-group w-100 mt-5">
                                        <li class="list-group-item">
                                            <div class="other-message">
                                                <div class="media">
                                                    <div class="media-left align-self-center mr-3">
                                                        <img src="assets/img/avatar/avatar-02.jpg" alt="..." class="img-fluid rounded-circle" style="width: 50px;">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="other-message-sender">Brandon Smith</div>
                                                        <div class="other-message-time">Are you serious? - 3 min ago</div>
                                                    </div>
                                                    <div class="media-right align-self-center">
                                                        <div class="actions">
                                                            <a href="app-chat.html"><i class="la la-reply reply"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="other-message">
                                                <div class="media">
                                                    <div class="media-left align-self-center mr-3">
                                                        <img src="assets/img/avatar/avatar-03.jpg" alt="..." class="img-fluid rounded-circle" style="width: 50px;">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="other-message-sender">Louis Henry</div>
                                                        <div class="other-message-time">Bonne idée, coucou à ... - 10 min ago</div>
                                                    </div>
                                                    <div class="media-right align-self-center">
                                                        <div class="actions">
                                                            <a href="app-chat.html"><i class="la la-reply reply"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="other-message">
                                                <div class="media">
                                                    <div class="media-left align-self-center mr-3">
                                                        <img src="assets/img/avatar/avatar-05.jpg" alt="..." class="img-fluid rounded-circle" style="width: 50px;">
                                                    </div>
                                                    <div class="media-body align-self-center">
                                                        <div class="other-message-sender">Megan Duncan</div>
                                                        <div class="other-message-time">See you later! - 20 min ago</div>
                                                    </div>
                                                    <div class="media-right align-self-center">
                                                        <div class="actions">
                                                            <a href="app-chat.html"><i class="la la-reply reply"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End Widget 18 -->
                        <!-- Begin Widget 19 -->
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                            <div class="widget widget-19 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>New Meeting</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-bell-slash"></i>Disable Alerts
                                                </a>
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Edit Widget
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <div class="widget-body p-0">
                                    <div class="form-group row mt-3 mr-0 mb-3 ml-0">
                                        <div class="col-xl-12">
                                            <label class="form-control-label">Meeting Name</label>
                                            <input type="text" value="My Meeting" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group row mr-0 mb-3 ml-0">
                                        <div class="col-xl-8 mb-3">
                                            <label class="form-control-label">Date</label>
                                            <select name="meeting-date" class="custom-select form-control">
                                                <option value="">Select Date</option>
                                                <option value="01">Sun 1 April</option>
                                                <option value="02">Mon 2 April</option>
                                                <option value="03">Tue 3 April</option>
                                                <option value="04">Wed 4 April</option>
                                                <option value="05">Thu 5 April</option>
                                                <option value="07">Fri 6 April</option>
                                                <option value="08">Sat 7 April</option>
                                                <option value="09">Sun 8 April</option>
                                                <option value="10">Mon 9 April</option>
                                                <option value="11">Tue 10 April</option>
                                                <option value="12">Wed 11 April</option>
                                                <option value="05">Thu 12 April</option>
                                                <option value="07">Fri 13 April</option>
                                                <option value="08">Sat 14 April</option>
                                                <option value="09">Sun 15 April</option>
                                                <option value="10">Mon 16 April</option>
                                                <option value="11">Tue 17 April</option>
                                                <option value="12">Wed 18 April</option>
                                                <option value="05">Thu 19 April</option>
                                                <option value="07">Fri 20 April</option>
                                                <option value="08">Sat 21 April</option>
                                                <option value="09">Sun 22 April</option>
                                                <option value="10">Mon 23 April</option>
                                                <option value="11">Tue 24 April</option>
                                                <option value="04">Wed 25 April</option>
                                                <option value="05">Thu 26 April</option>
                                                <option value="07">Fri 27 April</option>
                                                <option value="08">Sat 28 April</option>
                                                <option value="09">Sun 29 April</option>
                                                <option value="10">Mon 30 April</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-4">
                                            <label class="form-control-label">Hour</label>
                                            <select name="meeting-hour" class="custom-select form-control">
                                                <option value="">Select Hour</option>
                                                <option value="01">07:00 am</option>
                                                <option value="02">08:00 am</option>
                                                <option value="03">09:00 am</option>
                                                <option value="04">10:00 am</option>
                                                <option value="05">11:00 am</option>
                                                <option value="07">12:00 am</option>
                                                <option value="08">01:00 pm</option>
                                                <option value="09">02:00 pm</option>
                                                <option value="10">03:00 pm</option>
                                                <option value="08">04:00 pm</option>
                                                <option value="09">05:00 pm</option>
                                                <option value="10">06:00 pm</option>
                                                <option value="08">07:00 pm</option>
                                                <option value="09">08:00 pm</option>
                                                <option value="10">09:00 pm</option>
                                                <option value="08">10:00 pm</option>
                                                <option value="09">11:00 pm</option>
                                                <option value="10">12:00 pm</option>
                                            </select>
                                        </div>
                                    </div>
                                    <ul class="list-group w-100 widget-scroll" style="max-height:250px;">
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-02.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Brandon Smith</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-03.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Louis Henry</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-04.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Nathan Hunter</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-05.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Megan Duncan</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-06.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Beverly Oliver</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-07.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Lisa Garett</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-08.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Peter Collins</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media">
                                                <div class="media-left align-self-center mr-3">
                                                    <img src="assets/img/avatar/avatar-09.jpg" alt="..." class="img-fluid rounded-circle" style="width: 35px;">
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="people-name">Michael Bradley</div>
                                                </div>
                                                <div class="media-right align-self-center">
                                                    <div class="checkbox check"></div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    <div class="text-center mt-4 mb-3">
                                        <button type="button" class="btn btn-gradient-01" data-toggle="modal" data-target="#delay-modal">
                                            Create Meeting
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Widget 19 -->
                        <!-- Begin Widget 20 -->
                        <div class="col-xl-4">
                            <div class="widget widget-20 has-shadow">
                                <!-- Begin Widget Header -->
                                <div class="widget-header bordered d-flex align-items-center">
                                    <h2>Files</h2>
                                    <div class="widget-options">
                                        <div class="dropdown">
                                            <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle">
                                                <i class="la la-ellipsis-h"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item">
                                                    <i class="la la-edit"></i>Manage Files
                                                </a>
                                                <a href="#" class="dropdown-item faq">
                                                    <i class="la la-question-circle"></i>FAQ
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Widget Header -->
                                <div class="widget-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="widget20 owl-carousel">
                                                <div class="item">
                                                    <div class="card-image">
                                                        <img src="assets/img/background/03.jpg" alt="...">
                                                        <div class="card-overlay card-overlay-01">
                                                            <div class="card-overlay-content">
                                                                <div class="category">
                                                                    <a href="#">Category</a>
                                                                </div>
                                                                <a href="#0" class="card-title">Title Collection</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="card-image">
                                                        <img src="assets/img/background/04.jpg" alt="...">
                                                        <div class="card-overlay card-overlay-02">
                                                            <div class="card-overlay-content">
                                                                <div class="category">
                                                                    <a href="#">Category</a>
                                                                </div>
                                                                <a href="#0" class="card-title">Title Collection</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="card-image">
                                                        <img src="assets/img/background/05.jpg" alt="...">
                                                        <div class="card-overlay card-overlay-01">
                                                            <div class="card-overlay-content">
                                                                <div class="category">
                                                                    <a href="#">Category</a>
                                                                </div>
                                                                <a href="#0" class="card-title">Title Collection</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="card-image">
                                                        <img src="assets/img/background/02.jpg" alt="...">
                                                        <div class="card-overlay card-overlay-02">
                                                            <div class="card-overlay-content">
                                                                <div class="category">
                                                                    <a href="#">Category</a>
                                                                </div>
                                                                <a href="#0" class="card-title">Title Collection</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-5 mr-0 ml-0">
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center mb-4">
                                            <div class="media w-100">
                                                <div class="align-self-center mr-2">
                                                    <i class="la la-file-video-o"></i>
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="files-title"><a href="#">My Video</a></div>
                                                    <div class="files-number">84 Files</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center mb-4">
                                            <div class="media w-100">
                                                <div class="align-self-center mr-2">
                                                    <i class="la la-file-audio-o"></i>
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="files-title"><a href="#">My Songs</a></div>
                                                    <div class="files-number">786 Files</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center mb-4">
                                            <div class="media w-100">
                                                <div class="align-self-center mr-2">
                                                    <i class="la la-file-picture-o"></i>
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="files-title"><a href="#">Photos</a></div>
                                                    <div class="files-number">189 Files</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center mb-4">
                                            <div class="media w-100">
                                                <div class="align-self-center mr-2">
                                                    <i class="la la-file-zip-o"></i>
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="files-title"><a href="#">Template</a></div>
                                                    <div class="files-number">36 Files</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center mb-4">
                                            <div class="media w-100">
                                                <div class="align-self-center mr-2">
                                                    <i class="la la-file-pdf-o"></i>
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="files-title"><a href="#">Pdf</a></div>
                                                    <div class="files-number">19 Files</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex justify-content-center mb-4">
                                            <div class="media w-100">
                                                <div class="align-self-center mr-2">
                                                    <i class="la la-file-powerpoint-o"></i>
                                                </div>
                                                <div class="media-body align-self-center">
                                                    <div class="files-title"><a href="#">Presentation</a></div>
                                                    <div class="files-number">263 Files</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Widget 20 -->
                    </div>
                    <!-- End Row -->
                </div>
                <!-- End Container -->
                <!-- Begin Page Footer-->
                <footer class="main-footer">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-start justify-content-lg-start justify-content-md-start justify-content-center">
                            <p class="text-gradient-02">Develop With <i class="text-danger">&hearts;</i> by Farhan</p>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-end justify-content-lg-end justify-content-md-end justify-content-center">
                            <ul class="nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="documentation.html">Documentation</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="changelog.html">Changelog</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </footer>
                <!-- End Page Footer -->
                <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
            </div>
            <!-- End Content -->
        </div>
        <!-- End Page Content -->
    </div>
    <!-- Begin Success Modal -->
    <div id="delay-modal" class="modal fade">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <div class="sa-icon sa-success animate" style="display: block;">
                        <span class="sa-line sa-tip animateSuccessTip"></span>
                        <span class="sa-line sa-long animateSuccessLong"></span>
                        <div class="sa-placeholder"></div>
                        <div class="sa-fix"></div>
                    </div>
                    <div class="section-title mt-5 mb-5">
                        <h2 class="text-dark">Meeting successfully created</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Success Modal -->
    <!-- Begin Modal -->
    <div id="modal-view-event" class="modal modal-top fade calendar-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title event-title"></h4>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">×</span>
                        <span class="sr-only">close</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="media">
                        <div class="media-left align-self-center mr-3">
                            <div class="event-icon"></div>
                        </div>
                        <div class="media-body align-self-center mt-3 mb-3">
                            <div class="event-body"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal -->
    <!-- Begin Vendor Js -->
    <script src="assets/vendors/js/base/jquery.min.js"></script>
    <script src="assets/vendors/js/base/core.min.js"></script>
    <!-- End Vendor Js -->
    <!-- Begin Page Vendor Js -->
    <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
    <script src="assets/vendors/js/chart/chart.min.js"></script>
    <script src="assets/vendors/js/progress/circle-progress.min.js"></script>
    <script src="assets/vendors/js/calendar/moment.min.js"></script>
    <script src="assets/vendors/js/calendar/fullcalendar.min.js"></script>
    <script src="assets/vendors/js/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/vendors/js/app/app.js"></script>
    <!-- End Page Vendor Js -->
    <!-- Begin Page Snippets -->
    <script src="assets/js/dashboard/dashboard.js"></script>
    <!-- End Page Snippets -->
    <!-- script map -->
    <script>
        var map;
        var cities = [];

        function initMap() {
            map = new google.maps.Map(document.getElementById("layer-control"), {
                center: {
                    lat: 39.75,
                    lng: -104.9
                },
                zoom: 11,
            });

            var firstIcon = {
                url: "assets/img/avatar/avatar-02.jpg",
                scaledSize: new google.maps.Size(80, 80),
            };

            var secondIcon = {
                url: "assets/img/avatar/avatar-04.jpg",
                scaledSize: new google.maps.Size(80, 80),
            };

            var thirdIcon = {
                url: "assets/img/avatar/avatar-05.jpg",
                scaledSize: new google.maps.Size(80, 80),
            };

            var firstPopup =
                "Brandon Smith <span class='badge-text badge-text-small info ml-2'>Paid</span>";
            var secondPopup =
                "Nathan Hunter <span class='badge-text badge-text-small danger ml-2'>Failed</span>";
            var thirdPopup =
                "Megan Duncan <span class='badge-text badge-text-small info ml-2'>Paid</span>";

            addMarker({
                lat: 39.76,
                lng: -104.9
            }, firstIcon, firstPopup);
            addMarker({
                lat: 39.68,
                lng: -104.99
            }, secondIcon, secondPopup);
            addMarker({
                lat: 39.73,
                lng: -104.8
            }, thirdIcon, thirdPopup);

            // Menambahkan layer satelit
            map.mapTypes.set(
                "satellite",
                new google.maps.ImageMapType({
                    getTileUrl: function(coord, zoom) {
                        return (
                            "https://mt0.google.com/vt/lyrs=s&x=" +
                            coord.x +
                            "&y=" +
                            coord.y +
                            "&z=" +
                            zoom
                        );
                    },
                    tileSize: new google.maps.Size(256, 256),
                    name: "Satellite",
                    maxZoom: 20,
                })
            );

            // Menampilkan tombol untuk mengganti layer satelit
            map.setMapTypeId("satellite");
        }

        function addMarker(location, icon, content) {
            var marker = new google.maps.Marker({
                position: location,
                map: map,
                icon: icon,
            });

            var infowindow = new google.maps.InfoWindow({
                content: content,
            });

            marker.addListener("click", function() {
                infowindow.open(map, marker);
            });

            cities.push(marker);
        }
        initMap();
    </script>
    <!-- script pelanggan -->
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'assets/data/total_pelanggan.php',
                method: 'GET',
                success: function(response) {
                    $('.pelanggan-stats').eq(0).find('.number').text(response.aktif);
                    $('.pelanggan-stats').eq(1).find('.number').text(response.pakai);
                    $('.pelanggan-stats').eq(2).find('.number').text('Rp. ' + response.bayar + ',-');
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    </script>
    <!-- script dma -->
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'assets/data/dma.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    let tableBody = $('#order-table-body');
                    tableBody.empty(); // Mengosongkan baris yang ada untuk menghindari duplikasi
                    data.forEach(order => {
                        let colorClass;
                        if (order.persentase >= 50) {
                            colorClass = 'text-danger'; // Merah
                        } else if (order.persentase >= 25) {
                            colorClass = 'text-warning'; // Kuning
                        } else {
                            colorClass = 'text-success'; // Hijau
                        }

                        let row = `
                    <tr>
                        <td style="width:5%;">
                            <div class="styled-checkbox mt-2">
                                <input type="checkbox" name="cb${order.id}" id="cb${order.id}">
                                <label for="cb${order.id}"></label>
                            </div>
                        </td>
                        <td>${order.nama_dma}</td>
                        <td>${order.pelanggan}</td>
                        <td>${order.distribusi}</td>
                        <td>${order.pemakaian}</td>
                        <td>${order.kehilangan}</td>
                        <td class="${colorClass}">${order.persentase}%</td>
                    </tr>
                `;
                        tableBody.append(row); // Menambahkan baris ke tabel body
                    });
                }
            });
        });
    </script>
</body>

</html>