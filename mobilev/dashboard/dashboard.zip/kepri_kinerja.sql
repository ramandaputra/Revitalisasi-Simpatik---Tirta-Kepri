/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 5.5.9 : Database - kepri_kinerja
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`kepri_kinerja` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `kepri_kinerja`;

/*Table structure for table `aspek` */

DROP TABLE IF EXISTS `aspek`;

CREATE TABLE `aspek` (
  `aspek_id` int(2) NOT NULL AUTO_INCREMENT,
  `aspek_kinerja` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`aspek_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `aspek` */

insert  into `aspek`(`aspek_id`,`aspek_kinerja`) values 
(1,'Aspek Keuangan'),
(2,'Aspek Pelayanan'),
(3,'Aspek Operasional'),
(4,'Aspek SDM');

/*Table structure for table `indikator` */

DROP TABLE IF EXISTS `indikator`;

CREATE TABLE `indikator` (
  `indikator_id` int(2) NOT NULL AUTO_INCREMENT,
  `aspek_id` int(2) NOT NULL,
  `indikator` varchar(100) DEFAULT NULL,
  KEY `indikator_id` (`indikator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Data for the table `indikator` */

insert  into `indikator`(`indikator_id`,`aspek_id`,`indikator`) values 
(1,1,'Return on Equity'),
(2,1,'Ratio Operasi'),
(3,1,'Cash Ratio'),
(4,1,'Efisiensi Penagihan'),
(5,1,'Solvabilitas'),
(6,2,'Cakupan Pelayanan'),
(7,2,'Pertumbuhan Pelanggan'),
(8,2,'Penyelesaian Pengaduan'),
(9,2,'Kualitas Air Pelanggan'),
(10,2,'Konsumsi Air Pelanggan'),
(11,3,'Ratio Efisiensi Produksi'),
(12,3,'Air Tidak Berekening'),
(13,3,'Jam Operasi Pelayanan'),
(14,3,'Tekanan Air Pelanggan'),
(15,3,'Penggantian Meter Pelanggan'),
(16,4,'Jumlah Pegawai'),
(17,4,'Ratio Pegawai Diklat'),
(18,4,'Ratio Biaya Diklat');

/*Table structure for table `kinerja` */

DROP TABLE IF EXISTS `kinerja`;

CREATE TABLE `kinerja` (
  `aspek_id` int(2) DEFAULT NULL,
  `periode` date DEFAULT NULL,
  `indikator` varchar(200) DEFAULT NULL,
  `deskripsi1` varchar(100) DEFAULT NULL,
  `data1` decimal(50,0) DEFAULT NULL,
  `deskripsi2` varchar(100) DEFAULT NULL,
  `data2` decimal(50,0) DEFAULT NULL,
  `hasil` varchar(10) DEFAULT NULL,
  `score` varchar(3) DEFAULT NULL,
  `bobot` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `kinerja` */

insert  into `kinerja`(`aspek_id`,`periode`,`indikator`,`deskripsi1`,`data1`,`deskripsi2`,`data2`,`hasil`,`score`,`bobot`) values 
(1,'2024-01-01','1','Laba Rugi Bersih',-120921083,'Jumlah Ekuitas',92459569324,'-0,02','1.0',NULL),
(1,'2024-01-01','2','Biaya Operasi',2756693639,'Pendapatan Operasi',2635772556,'1,05','1.0',NULL),
(1,'2024-01-01','3','Kas',8388120715,'Hutang Lancar',684946056,'1224,64','5.0',NULL),
(1,'2024-01-01','4','Penerimaan Rekening Air',2021943450,'Rekening Air Ditagihkan',2485824050,'81,34','3.0',NULL),
(1,'2024-01-01','5','Total Aktiva',94476838614,'Total Hutang',2017269290,'4683,40','5.0',NULL),
(2,'2024-01-01','6','Jumlah Penduduk Terlayani',123201,'Jumlah Penduduk Wilayah Pelayanan',267011,'46.14','3.0','0.15'),
(2,'2024-01-01','7','Pelanggan bualan ini - Pelanggan Bulan Lalu',27,'Pelanggan Bulan Lalu (Aktif dan Putus)',30645,NULL,NULL,NULL),
(2,'2024-01-01','8','Pengaduan Selesai',367,'Jumlah Pengaduan',401,NULL,NULL,NULL),
(2,'2024-01-01','9','Jumlah Uji Kualitas yang Memenuhi Syarat',0,'Jumlah yang Diuji',13,NULL,NULL,NULL),
(2,'2024-01-01','10','Air Terjual Domestik',353026,'Pelanggan Domestik',22375,NULL,NULL,NULL),
(1,'2024-02-01','1','Laba Rugi Bersih',-14232668,'Jumlah Ekuitas',92444917756,'-0,13','1.0',NULL),
(1,'2024-02-01','2','Biaya Operasi',2687864718,'Pendapatan Operasi',2673632050,'1,01','1.0',NULL),
(1,'2024-02-01','3','Kas',8553588504,'Utang Lancar',1220758166,'700,68','5.0',NULL),
(1,'2024-02-01','4','Penerimaan Rekening Air',2045198350,'Rekening Air Ditagihkan',2543355150,'80,41','3.0',NULL),
(1,'2024-02-01','5','Total Aktiva',94549907843,'Total Hutang',2104990087,'4491,70','5.0',NULL),
(1,'2024-04-01','1','Laba Rugi Bersih',211093495,'Jumlah Ekuitas',91773199073,'0.23','2.0','0.11'),
(1,'2024-04-01','2','Biaya Operasi',2798167855,'Pendapatan Operasi',3009261350,'0.93','2.0','0.11'),
(1,'2024-04-01','3','Kas',8454108887,'Hutang Lancar',1117846734,'756.29','5.0','0.28'),
(1,'2024-04-01','4','Penerimaan Rekening Air',2033059350,'Rekening Air Ditagihkan',2882740450,'70.53','1.0','0.06'),
(1,'2024-04-01','5','Total Aktiva',93775277728,'Total Hutang',2002078655,'4683.90','5.0','0.15'),
(2,'2024-02-01','6','Jumlah Penduduk Terlayani',123356,'Jumlah Penduduk Wilayah Pelayanan',267011,'46.20','3.0','0.15');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
