<?php
session_start();
$is_logged_in = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SIMPATIK V2.0 - Produksi</title>
    <meta name="description" content="SIMPATIK">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Google Fonts -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB861q02tPb43SuX8bSUB_mGJgo1KJ-YjE&callback=initMap"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
    <script>
        WebFont.load({
            google: {
                "families": ["Montserrat:400,500,600,700", "Noto+Sans:400,700"]
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="assets/vendors/css/base/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendors/css/base/elisyam-1.5-dark.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel/owl.theme.min.css">
    <style>
        .carousel-container {
            position: relative;
            overflow: hidden;
            width: 100%;
            height: 100%;
        }

        .carousel {
            display: flex;
            transition: transform 0.5s ease;
            width: 100%;
        }

        .carousel-slide {
            min-width: 100%;
            position: relative;
        }

        .carousel img {
            width: 100%;
            height: auto;
            display: block;
        }

        .alt-text {
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.5);
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
            white-space: nowrap;
        }

        .carousel-controls {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }

        .carousel-controls button {
            background: rgba(0, 0, 0, 0.5);
            border: none;
            color: #fff;
            font-size: 18px;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .carousel-controls button:hover {
            background: rgba(0, 0, 0, 0.7);
        }
    </style>
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>

<body id="page-top">
    <!-- Begin Preloader -->
    <div id="preloader">
        <div class="canvas">
            <img src="assets/img/logo-2.png" alt="logo" class="loader-logo">
            <div class="spinner"></div>
        </div>
    </div>
    <!-- End Preloader -->
    <div class="page">
        <!-- Begin Header -->
        <header class="header">
            <nav class="navbar fixed-top">
                <!-- Begin Topbar -->
                <div class="navbar-holder d-flex align-items-center align-middle justify-content-between">
                    <!-- Begin Logo -->
                    <div class="navbar-header">
                        <a href="db-default.html" class="navbar-brand">
                            <div class="brand-image brand-big">
                                <img src="assets/img/logo-big-2.png" alt="logo" class="logo-big">
                            </div>
                            <div class="brand-image brand-small">
                                <img src="assets/img/logo-2.png" alt="logo" class="logo-small">
                            </div>
                        </a>
                        <!-- Toggle Button -->
                        <a id="toggle-btn" href="#" class="menu-btn active">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                        <!-- End Toggle -->
                    </div>
                    <!-- End Logo -->
                    <!-- Begin Navbar Menu -->
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center pull-right">
                        <!-- User -->
                        <li class="nav-item dropdown">
                            <?php if ($is_logged_in) : ?>
                                <a id="user" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link">
                                    <img src="assets/img/avatar/avatar-01.jpg" alt="..." class="avatar rounded-circle">
                                </a>
                                <ul aria-labelledby="user" class="user-size dropdown-menu">
                                    <li class="welcome">
                                        <a href="#" class="edit-profil"><i class="la la-gear"></i></a>
                                        <img src="assets/img/avatar/avatar-01.jpg" alt="..." class="rounded-circle">
                                    </li>
                                    <li>
                                        <a href="pages-profile.html" class="dropdown-item">Profile</a>
                                    </li>
                                    <li>
                                        <a href="#" class="dropdown-item no-padding-bottom">Settings</a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" href="pages-logout.php" class="dropdown-item logout text-center"><i class="ti-power-off"></i></a>
                                    </li>
                                </ul>
                            <?php else : ?>
                                <button type="button" class="btn btn-shadow mr-1 mb-2" onclick="window.location.href='pages-login.html'">Login</button>
                            <?php endif; ?>
                        </li>
                        <!-- End User -->
                    </ul>
                    <!-- End Navbar Menu -->
                </div>
                <!-- End Topbar -->
            </nav>
        </header>
        <!-- End Header -->
        <!-- Begin Page Content -->
        <div class="page-content d-flex align-items-stretch">
            <div class="default-sidebar">
                <!-- Begin Side Navbar -->
                <nav class="side-navbar box-scroll sidebar-scroll">
                    <!-- Begin Main Navigation -->
                    <ul class="list-unstyled">
                        <span class="heading">Kinerja</span>
                        <li><a href="#keuangan" aria-expanded="false" data-toggle="collapse"><i class="la la-money"></i><span>Aspek Keuangan</span></a>
                            <ul id="keuangan" class="collapse list-unstyled pt-0">
                                <li><a href="return-on-equity.php">Return on Equity</a></li>
                                <li><a href="ratio-operasi.php">Rasio Operasi</a></li>
                                <li><a href="cash-ratio.php">Rasio Kas</a></li>
                                <li><a href="efisiensi-penagihan.php">Efisiensi Penagihan</a></li>
                                <li><a href="solvabilitas.php">Solvabilitas</a></li>
                            </ul>
                        </li>
                        <li><a href="#pelayanan" aria-expanded="false" data-toggle="collapse"><i class="la la-thumbs-up"></i><span>Aspek Pelayanan</span></a>
                            <ul id="pelayanan" class="collapse list-unstyled pt-0">
                                <li><a href="cakupan-pelayanan.php">Cakupan Pelayanan</a></li>
                                <li><a href="pertumbuhan-pelanggan.php">Pertumbuhan Pelanggan</a></li>
                                <li><a href="penyelesaian-pengaduan.php">Penyelesaian Pengaduan</a></li>
                                <li><a href="kualitas-air.php">Kualitas Air</a></li>
                                <li><a href="konsumsi-air.php">Konsumsi Air</a></li>
                            </ul>
                        </li>
                        <li><a href="#operasional" aria-expanded="false" data-toggle="collapse"><i class="la la-tint"></i><span>Aspek Operasional</span></a>
                            <ul id="operasional" class="collapse list-unstyled pt-0">
                                <li><a href="rasio-efisiensi-produksi.php">Rasio Efisiensi Produksi</a></li>
                                <li><a href="air-tidak-berekening.php">Air Tidak Berekening</a></li>
                                <li><a href="jam-operasi.php">Jam Operasi</a></li>
                                <li><a href="tekanan-air.php">Tekanan Air</a></li>
                                <li><a href="penggantian-meter.php">Penggantian Meter</a></li>
                            </ul>
                        </li>
                        <li><a href="#sdm" aria-expanded="false" data-toggle="collapse"><i class="la la-group"></i><span>Aspek SDM</span></a>
                            <ul id="sdm" class="collapse list-unstyled pt-0">
                                <li><a href="jumlah-pegawai.php">Jumlah Pegawai</a></li>
                                <li><a href="rasio-pegawai-diklat.php">Rasio Pegawai Diklat</a></li>
                                <li><a href="rasio-biaya-diklat.php">Rasio Biaya Diklat</a></li>
                            </ul>
                        </li>
                    </ul>
                    <span class="heading">Target x Realisasi</span>
                    <ul class="list-unstyled">
                        <li><a href="#tek" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>TEKNIK</span></a>
                            <ul id="tek" class="collapse list-unstyled pt-0">
                                <li><a href="produksi.php">Produksi</a></li>
                                <li><a href="distribusi.php">Distribusi</a></li>
                                <li><a href="tingkat-kehilangan-air.php">Tingkat Kehilangan Air</a></li>
                                <li><a href="perawatan-meter.php">Perawatan Meter</a></li>
                                <li><a href="pemutusan-tunggakan.php">Pemutusan Tunggakan</a></li>
                            </ul>
                        </li>
                        <li><a href="#hbl" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>HUBLANG</span></a>
                            <ul id="hbl" class="collapse list-unstyled pt-0">
                                <li><a href="drd-posting.php">DRD Posting</a></li>
                                <li><a href="pertumbuhan-pelanggan.php">Pertumbuhan Pelanggan</a></li>
                                <li><a href="pengaduan-pelanggan.php">Pengaduan Pelanggan</a></li>
                                <li><a href="perbaikan-rekening.php">Perbaikan Rekening</a></li>
                                <li><a href="pembacaan-meter.php">Pembacaan Meter</a></li>
                            </ul>
                        </li>
                        <li><a href="#keu" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>KEUANGAN</span></a>
                            <ul id="keu" class="collapse list-unstyled pt-0">
                                <li><a href="efisiensi-penagihan.php">Efisiensi Penagihan</a></li>
                                <li><a href="penerimaan.php">Penerimaan</a></li>
                                <li><a href="pengeluaran.php">Pengeluaran</a></li>
                                <li><a href="arus-kas.php">Arus Kas</a></li>
                            </ul>
                        </li>
                        <li><a href="#spi" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>SPI</span></a>
                            <ul id="spi" class="collapse list-unstyled pt-0">
                                <li><a href="tunggakan-empat-bulan.php">Tunggakan > 4 Bulan</a></li>
                                <li><a href="monitoring-spi.php">Monitoring SPI</a></li>
                            </ul>
                        </li>
                        <li><a href="#spka" aria-expanded="false" data-toggle="collapse"><i class="la la-puzzle-piece"></i><span>SPKA</span></a>
                            <ul id="spka" class="collapse list-unstyled pt-0">
                                <li><a href="monitoring-dma.php">Monitoring DMA</a></li>
                                <li><a href="kegiatan-spka.php">Kegiatan SPKA</a></li>
                                <li><a href="gis.php">GIS</a></li>
                            </ul>
                        </li>
                        <li><a href="maps-leaflet.html"><i class="la la-map"></i><span>Maps</span></a></li>
                    </ul>
                    <span class="heading">Input Data</span>
                    <ul class="list-unstyled">
                        <?php if ($is_logged_in) : ?>
                            <li><a href="#aspek-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>Posting Kinerja</span></a>
                                <ul id="aspek-input" class="collapse list-unstyled pt-0">
                                    <li><a href="aspek-keuangan-input.php">Aspek Keuangan</a></li>
                                    <li><a href="aspek-pelayanan-input.php">Aspek Pelayanan</a></li>
                                    <li><a href="aspek-operasional-input.php">Aspek Operasional</a></li>
                                    <li><a href="aspek-sdm-input.php">Aspek SDM</a></li>
                                </ul>
                            </li>
                            <li><a href="#produksi-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>Jurnal Produksi</span></a>
                                <ul id="produksi-input" class="collapse list-unstyled pt-0">
                                    <li><a href="air-baku-input.php">Air Baku</a></li>
                                    <li><a href="ipa-input.php">IPA</a></li>
                                    <li><a href="pompa-input.php">Pompa</a></li>
                                </ul>
                            </li>
                            <li><a href="#spka-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>SPKA</span></a>
                                <ul id="spka-input" class="collapse list-unstyled pt-0">
                                    <li><a href="monitoring-dma-input.php">Monitoring DMA</a></li>
                                    <li><a href="kegiatan-spka-input.php">Kegiatan SPKA</a></li>
                                </ul>
                            </li>
                            <li><a href="#spi-input" aria-expanded="false" data-toggle="collapse"><i class="la la-file-text"></i><span>SPI</span></a>
                                <ul id="spi-input" class="collapse list-unstyled pt-0">
                                    <li><a href="monitoring-dma-input.php">Monitoring SPI</a></li>
                                </ul>
                            </li>
                            <li><a href="#user-input" aria-expanded="false" data-toggle="collapse"><i class="la la-key"></i><span>Users</span></a>
                                <ul id="user-input" class="collapse list-unstyled pt-0">
                                    <li><a href="registrasi.php">Registrasi</a></li>
                                    <li><a href="reset-password.php">Reset Password</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <!-- End Main Navigation -->
                </nav>
                <!-- End Side Navbar -->
            </div>
            <!-- End Left Sidebar -->
            <div class="content-inner">
                <div class="container-fluid">
                    <!-- Begin Page Header-->
                    <div class="row">
                        <div class="page-header">
                            <div class="d-flex align-items-center">
                                <h2 class="page-header-title">Produksi</h2>
                                <div>
                                    <div class="page-header-tools">
                                        <a class="btn btn-gradient-01" href="index.php">Dashboard</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Page Header -->
                    <div class="widget-body">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="i-base-tab-1" data-toggle="tab" href="#i-tab-1" role="tab" aria-controls="i-tab-1" aria-selected="true"><i class="ion-stats-bars mr-2"></i>Sei Pulai</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="i-base-tab-2" data-toggle="tab" href="#i-tab-2" role="tab" aria-controls="i-tab-2" aria-selected="false"><i class="ion-stats-bars mr-2"></i>Sei Gesek</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="i-base-tab-3" data-toggle="tab" href="#i-tab-3" role="tab" aria-controls="i-tab-3" aria-selected="false"><i class="ion-stats-bars mr-2"></i>Sei Jago</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="i-base-tab-4" data-toggle="tab" href="#i-tab-4" role="tab" aria-controls="i-tab-4" aria-selected="false"><i class="ion-stats-bars mr-2"></i>Kolong Enam</a>
                            </li>
                        </ul>
                        <div class="tab-content pt-3">
                            <div class="tab-pane fade show active" id="i-tab-1" role="tabpanel" aria-labelledby="i-base-tab-1">
                                <!-- Begin Row -->
                                <div class="row flex-row">
                                    <!-- Begin Facebook -->
                                    <div class="col-xl-4 col-md-6 col-sm-6">
                                        <div class="widget widget-12 has-shadow">
                                            <div class="widget-body">
                                                <div class="media">
                                                    <div class="align-self-center ml-5 mr-5">
                                                        <i class="ion-levels text-twitter"></i>
                                                    </div>
                                                    <div class="pelanggan-stats align-self-center">
                                                        <div class="title text-twitter">Tinggi Muka Air</div>
                                                        <div class="number">Loading...</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Facebook -->
                                    <!-- Begin Twitter -->
                                    <div class="col-xl-4 col-md-6 col-sm-6">
                                        <div class="widget widget-12 has-shadow">
                                            <div class="widget-body">
                                                <div class="media">
                                                    <div class="align-self-center ml-5 mr-5">
                                                        <i class="ion-waterdrop text-twitter"></i>
                                                    </div>
                                                    <div class="pelanggan-stats align-self-center">
                                                        <div class="title text-twitter">Produksi</div>
                                                        <div class="number">Loading...</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Twitter -->
                                    <!-- Begin Linkedin -->
                                    <div class="col-xl-4 col-md-6 col-sm-6">
                                        <div class="widget widget-12 has-shadow">
                                            <div class="widget-body">
                                                <div class="media">
                                                    <div class="align-self-center ml-5 mr-5">
                                                        <i class="ion-speedometer text-twitter"></i>
                                                    </div>
                                                    <div class="pelanggan-stats align-self-center">
                                                        <div class="title text-twitter">Tekanan</div>
                                                        <div class="number">Laoding...</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Linkedin -->
                                </div>
                                <!-- End Row -->
                                <!-- Begin Row -->
                                <div class="row flex-row">
                                    <div class="col-xl-12 col-md-6">
                                        <!-- Begin Widget 09 -->
                                        <div class="widget widget-09 has-shadow">
                                            <!-- Begin Widget Header -->
                                            <div class="widget-header d-flex align-items-center">
                                                <h2>Produksi Sei Pulai</h2>
                                            </div>
                                            <!-- End Widget Header -->
                                            <!-- Begin Widget Body -->
                                            <div class="widget-body">
                                                <div class="row">
                                                    <div class="col-xl-12 col-12 no-padding">
                                                        <div>
                                                            <canvas id="orders"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Widget 09 -->
                                    </div>
                                </div>
                                <!-- End Row -->
                                <div class="row flex-row">
                                    <div class="col-xl-8 col-md-6">
                                        <!-- Begin Widget 04 -->
                                        <div class="widget widget-04 has-shadow">
                                            <!-- Begin Widget Header -->
                                            <!-- Leaflet -->
                                            <div class="widget widget-38 has-shadow">
                                                <div class="widget-header bordered no-actions d-flex align-items-center">
                                                    <h4>Peta Jaringan</h4>
                                                </div>
                                                <div class="widget-body p-0">
                                                    <div id="layer-control" style="height: 485px"></div>
                                                </div>
                                                <!-- End Leaflet -->
                                            </div>
                                            <!-- End Widget Header -->
                                        </div>
                                        <!-- End Widget 04 -->
                                    </div>
                                    <div class="col-xl-4">
                                        <!-- Begin Widget 06 -->
                                        <div class="widget widget-06 has-shadow">
                                            <!-- Begin Widget Header -->
                                            <div class="widget-header bordered d-flex align-items-center">
                                                <h2>Tinggi Muka Air</h2>
                                            </div>
                                            <!-- End Widget Header -->
                                            <!-- Begin Widget Body -->
                                            <div class="widget-body p-0">
                                                <div id="list-group" class="widget-scroll" style="max-height:490px;">
                                                    <ul class="reviews list-group w-100" id="tma-list">
                                                        <!-- Data akan dimuat di sini oleh AJAX -->
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- End Widget Body -->
                                        </div>
                                        <!-- End Widget 06 -->
                                    </div>
                                </div>
                                <!-- End Row -->
                                <div class="row flex-row">
                                    <div class="col-xl-3 col-md-6">
                                        <!-- Begin Widget 08 -->
                                        <div class="widget widget-06 has-shadow">
                                            <!-- Begin Widget Header -->
                                            <div class="widget-header bordered d-flex align-items-center">
                                                <h2>Kualitas Air</h2>
                                            </div>
                                            <!-- End Widget Header -->
                                            <!-- Begin Widget Body -->
                                            <div class="widget-body p-0">
                                                <div id="list-group" class="widget-scroll" style="max-height:490px;">
                                                    <ul class="reviews list-group w-100" id="kualitas-air-list">
                                                        <!-- Data akan dimuat di sini oleh AJAX -->
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- End Widget Body -->
                                        </div>
                                        <!-- End Widget 08 -->
                                    </div>
                                    <div class="col-xl-9 col-md-6">
                                        <!-- Begin Widget 10 -->
                                        <div class="widget widget-10 has-shadow">
                                            <!-- Begin Widget Header -->
                                            <div class="widget-header bordered d-flex align-items-center">
                                                <h2>Proses Produksi</h2>
                                            </div>
                                            <!-- End Widget Header -->
                                            <!-- Begin Widget Body -->
                                            <div class="widget-body no-padding">
                                                <div class="carousel-container">
                                                    <div class="carousel">
                                                        <div class="carousel-slide">
                                                            <img src="assets/img/gif/GIF_WK.gif" alt="IPA WK">
                                                            <div class="alt-text">IPA WK</div>
                                                        </div>
                                                        <div class="carousel-slide">
                                                            <img src="assets/img/gif/GIF_RPD.gif" alt="IPA RPD">
                                                            <div class="alt-text">IPA RPD</div>
                                                        </div>
                                                        <div class="carousel-slide">
                                                            <img src="assets/img/gif/GIF_PSAB.gif" alt="IPA PSAB">
                                                            <div class="alt-text">IPA PSAB</div>
                                                        </div>
                                                        <div class="carousel-slide">
                                                            <img src="assets/img/gif/GIF_PCM.gif" alt="IPA PCM">
                                                            <div class="alt-text">IPA PCM</div>
                                                        </div>
                                                    </div>
                                                    <div class="carousel-controls">
                                                        <button id="prevBtn">&#10094;</button>
                                                        <button id="nextBtn">&#10095;</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Widget Body -->
                                        </div>
                                        <!-- End Widget 10 -->
                                    </div>
                                </div>
                                <!-- End Row -->
                            </div>
                            <div class="tab-pane fade" id="i-tab-2" role="tabpanel" aria-labelledby="i-base-tab-2">
                                <!-- Konten untuk Tab 2 -->
                            </div>
                            <div class="tab-pane fade" id="i-tab-3" role="tabpanel" aria-labelledby="i-base-tab-3">
                                <!-- Konten untuk Tab 3 -->
                            </div>
                            <div class="tab-pane fade" id="i-tab-4" role="tabpanel" aria-labelledby="i-base-tab-4">
                                <!-- Konten untuk Tab 4 -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Container -->
                <!-- Begin Page Footer-->
                <footer class="main-footer">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-start justify-content-lg-start justify-content-md-start justify-content-center">
                            <p class="text-gradient-02">Develop With <i class="text-danger">&hearts;</i> by Farhan</p>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-end justify-content-lg-end justify-content-md-end justify-content-center">
                            <ul class="nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="documentation.html">Documentation</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </footer>
                <!-- End Page Footer -->
                <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>
            </div>
            <!-- End Content -->
        </div>
        <!-- End Page Content -->
    </div>
    <!-- Begin Vendor Js -->
    <script src="assets/vendors/js/base/jquery.min.js"></script>
    <script src="assets/vendors/js/base/core.min.js"></script>
    <!-- End Vendor Js -->
    <!-- Begin Page Vendor Js -->
    <script src="assets/vendors/js/nicescroll/nicescroll.min.js"></script>
    <script src="assets/vendors/js/chart/chart.min.js"></script>
    <script src="assets/vendors/js/progress/circle-progress.min.js"></script>
    <script src="assets/vendors/js/calendar/moment.min.js"></script>
    <script src="assets/vendors/js/calendar/fullcalendar.min.js"></script>
    <script src="assets/vendors/js/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/vendors/js/app/app.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB861q02tPb43SuX8bSUB_mGJgo1KJ-YjE&callback=initMap&loading=async"></script>
    <!-- End Page Vendor Js -->
    <!-- Begin Page Snippets -->
    <script src="assets/js/dashboard/produksi.js"></script>
    <!-- End Page Snippets -->
    <!-- script map -->
    <script>
        var map;

        function initMap() {
            var mapOptions = {
                center: {
                    lat: 0.9159961,
                    lng: 104.5476493
                },
                zoom: 15,
                mapTypeId: 'satellite'
            };

            var map = new google.maps.Map(document.getElementById('layer-control'), mapOptions);

            $.getJSON("assets/data/get_geojson.php", function(geojsonData) {
                var geojsonLayer = new google.maps.Data({
                    map: map
                });

                geojsonLayer.setStyle({
                    strokeColor: 'orange', // Atur warna garis menjadi hijau
                    strokeWeight: 2, // Atur lebar garis
                    strokeOpacity: 0.8 // Atur opasitas garis
                });

                geojsonLayer.addGeoJson(geojsonData);
            });


            $.getJSON("assets/data/get_markers.php", function(markerData) {
                markerData.forEach(marker => {
                    var popupContent = `<b>${marker.name}</b><br>
                    <u>${marker.time}</u><br>
                    Pressure: ${marker.pressure} bar<br>
                    Flow: ${marker.flow} m³/h<br>
                    TDS: ${marker.tds} ppm<br>
                    Level: ${marker.level} m`;

                    var infowindow = new google.maps.InfoWindow({
                        content: popupContent,
                    });

                    // Hitung ukuran lingkaran berdasarkan nilai pressure
                    var circleRadius = calculateCircleRadius(marker.pressure);

                    var circleColor = marker.pressure >= 1 ? 'blue' : 'red'; // Warna biru untuk pressure >= 1, merah untuk pressure < 1

                    // Tambahkan marker dengan lingkaran (circle) dan label
                    var markerWithLabel = new google.maps.Marker({
                        position: new google.maps.LatLng(parseFloat(marker.latitude), parseFloat(marker.longitude)),
                        map: map,
                        label: {
                            text: marker.name,
                            fontSize: '12px',
                        },
                        icon: {
                            path: google.maps.SymbolPath.CIRCLE,
                            scale: circleRadius,
                            fillColor: circleColor, // Warna lingkaran
                            fillOpacity: 0.6, // Opasitas warna lingkaran
                            strokeWeight: 0, // Tidak ada border
                        },
                    });

                    // Tambahkan listener untuk menampilkan infowindow saat marker diklik
                    markerWithLabel.addListener('click', function() {
                        infowindow.open(map, markerWithLabel);
                    });
                });
            });

            // Fungsi untuk menghitung ukuran lingkaran berdasarkan nilai pressure
            function calculateCircleRadius(pressure) {
                return Math.max(0, 12 - pressure); // Contoh sederhana
            }

        }
    </script>
    <!-- script pelanggan -->
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'assets/data/total_pelanggan.php',
                method: 'GET',
                success: function(response) {
                    $('.pelanggan-stats').eq(0).find('.number').text(response.aktif);
                    $('.pelanggan-stats').eq(1).find('.number').text(response.pakai);
                    $('.pelanggan-stats').eq(2).find('.number').text('Rp. ' + response.bayar + ',-');
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    </script>
    <!-- script dma -->
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'assets/data/dma.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    let tableBody = $('#order-table-body');
                    tableBody.empty(); // Mengosongkan baris yang ada untuk menghindari duplikasi
                    data.forEach(order => {
                        let colorClass;
                        if (order.persentase >= 50) {
                            colorClass = 'text-danger'; // Merah
                        } else if (order.persentase >= 25) {
                            colorClass = 'text-warning'; // Kuning
                        } else {
                            colorClass = 'text-success'; // Hijau
                        }

                        let row = `
                    <tr>
                        <td style="width:5%;">
                            <div class="styled-checkbox mt-2">
                                <input type="checkbox" name="cb${order.id}" id="cb${order.id}">
                                <label for="cb${order.id}"></label>
                            </div>
                        </td>
                        <td>${order.nama_dma}</td>
                        <td>${order.pelanggan}</td>
                        <td>${order.distribusi}</td>
                        <td>${order.pemakaian}</td>
                        <td>${order.kehilangan}</td>
                        <td class="${colorClass}">${order.persentase}%</td>
                    </tr>
                `;
                        tableBody.append(row); // Menambahkan baris ke tabel body
                    });
                }
            });
        });
    </script>
    <!-- script tma -->
    <script>
        $(document).ready(function() {
            function loadTMA() {
                $.ajax({
                    url: 'assets/data/tma-seipulai.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        let tmaList = $('#tma-list');
                        tmaList.empty();
                        data.forEach(function(item) {
                            let date = new Date(item.waktu);
                            let formattedDate = ("0" + date.getDate()).slice(-2) + "/" +
                                ("0" + (date.getMonth() + 1)).slice(-2) + "/" +
                                date.getFullYear();
                            tmaList.append(
                                `<li class="list-group-item">
                                    <div class="media">
                                        <div class="media-body align-self-center">
                                            <div class="username">
                                                <h4>${item.waduk}</h4>
                                            </div>
                                            <div class="msg">
                                                <p><strong>Waktu:</strong> ${formattedDate}</p>
                                                <p><strong>TMA:</strong> ${item.tma} meter</p>
                                            </div>
                                        </div>
                                    </div>
                                </li>`
                            );
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching data:', error);
                    }
                });
            }

            // Muat data saat halaman dimuat
            loadTMA();

            // Muat data setiap 5 menit
            setInterval(loadTMA, 300000);
        });
    </script>
    <!-- script slide show -->
    <script>
        const carousel = document.querySelector('.carousel');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        let currentIndex = 0;

        function showSlide(index) {
            const slides = document.querySelectorAll('.carousel img');
            const totalSlides = slides.length;
            if (index >= totalSlides) {
                currentIndex = 0;
            } else if (index < 0) {
                currentIndex = totalSlides - 1;
            } else {
                currentIndex = index;
            }
            const offset = -currentIndex * 100;
            carousel.style.transform = `translateX(${offset}%)`;
        }

        prevBtn.addEventListener('click', () => {
            showSlide(currentIndex - 1);
        });

        nextBtn.addEventListener('click', () => {
            showSlide(currentIndex + 1);
        });

        // Auto-slide every 5 seconds
        setInterval(() => {
            showSlide(currentIndex + 1);
        }, 5000);
    </script>
    <!-- script kualitas air -->
    <script>
        $(document).ready(function() {
            function loadKualitasair() {
                $.ajax({
                    url: 'assets/data/kualitas-air-seipulai.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        let tmaList = $('#kualitas-air-list');
                        tmaList.empty();
                        data.forEach(function(item) {
                            let date = new Date(item.waktu);
                            let formattedDate = ("0" + date.getDate()).slice(-2) + "/" +
                                ("0" + (date.getMonth() + 1)).slice(-2) + "/" +
                                date.getFullYear();
                            tmaList.append(
                                `<li class="list-group-item">
                                    <div class="media">
                                        <div class="media-body align-self-center">
                                            <div class="username">
                                                <h4>${item.waduk}</h4>
                                            </div>
                                            <div class="msg">
                                                <p><strong>Waktu:</strong> ${formattedDate}</p>
                                                <p><strong>pH:</strong> ${item.ph} </p>
                                                <p><strong>TDS:</strong> ${item.tds} mg/L</p>
                                            </div>
                                        </div>
                                    </div>
                                </li>`
                            );
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching data:', error);
                    }
                });
            }

            // Muat data saat halaman dimuat
            loadKualitasair();

            // Muat data setiap 5 menit
            setInterval(loadKualitasair, 300000);
        });
    </script>
</body>

</html>